import xbmc
xbmc.executebuiltin("RunAddon(plugin.program.kingbuildupdate)")