#!/usr/bin/python
# -*- coding: utf-8 -*-
import sys
import xbmc, xbmcgui

xbmc.executebuiltin("RunAddon(service.kingbuildupdate)")

	