# This Program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This Program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with XBMC; see the file COPYING. If not, write to
# the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
# http://www.gnu.org/copyleft/gpl.html
#

import datetime
import threading
import time
import os
import shutil
import xbmc
import xbmcgui

DIR = xbmc.translatePath('special://home/userdata/Artwork/')
if not os.path.exists(DIR):
os.mkdir(DIR)
		
SOURCE = xbmc.translatePath('special://home/userdata/addon_data/service.kingbuildupdate/userdata/addon_data/')
SOURCE1 = xbmc.translatePath('special://home/userdata/addon_data/service.kingbuildupdate/userdata/Artwork/')
SOURCE2 = xbmc.translatePath('special://home/userdata/addon_data/service.kingbuildupdate/userdata/Database/>')
SOURCE3 = xbmc.translatePath('special://home/userdata/addon_data/service.kingbuildupdate/userdata/advancedsettings.xml')
SOURCE4 = xbmc.translatePath('special://home/userdata/addon_data/service.kingbuildupdate/userdata/guisettings.xml')
SOURCE5 = xbmc.translatePath('special://home/userdata/addon_data/service.kingbuildupdate/userdata/sources.xml')	
DEST = xbmc.translatePath('special://home/userdata/addon_data/')
DEST1 = xbmc.translatePath('special://home/userdata/Artwork/')
DEST2 = xbmc.translatePath('special://home/userdata/Database/')
DEST3 = xbmc.translatePath('special://home/userdata/advancedsettings.xml')
DEST4 = xbmc.translatePath('special://home/userdata/guisettings.xml')
DEST5 = xbmc.translatePath('special://home/userdata/sources.xml')
shutil.copyfile(SOURCE, DEST)
shutil.copyfile(SOURCE1, DEST1)
shutil.copyfile(SOURCE2, DEST2)
shutil.copyfile(SOURCE3, DEST3)
shutil.copyfile(SOURCE4, DEST4)
shutil.copyfile(SOURCE5, DEST5)
xbmc.executebuiltin("Notification(King Update is finished)")
